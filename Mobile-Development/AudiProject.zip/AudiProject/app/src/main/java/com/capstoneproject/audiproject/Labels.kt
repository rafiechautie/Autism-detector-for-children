package com.capstoneproject.audiproject

data class Labels(
    val labelName: String,
    val predictScore: Float
)
