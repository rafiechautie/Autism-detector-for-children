package com.capstoneproject.audiproject.ui.home

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.capstoneproject.audiproject.R
import com.capstoneproject.audiproject.databinding.ActivityHomeBinding
import com.capstoneproject.audiproject.ui.detection.AutismDetectionActivity
import com.capstoneproject.audiproject.ui.detection.FiturDetection
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.common.ops.NormalizeOp
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.image.ops.ResizeOp
import java.io.IOException

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private lateinit var user: FirebaseUser

    private lateinit var uri: Uri

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        user = FirebaseAuth.getInstance().currentUser!!
        binding.textView.text = user.displayName

        setupButton()
    }

    private fun setupButton() {
        binding.apply {

            btnDetection.setOnClickListener {
                ImagePicker.Companion.with(this@HomeActivity)
                    .compress(1024)
                    .maxResultSize(1080, 1080)
                    .start(2)
            }

        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == RESULT_OK && data != null) {
            uri = data.data!!
            try {
                val intent = Intent(this, FiturDetection::class.java)
                intent.putExtra(FiturDetection.URI_IMAGE, uri.toString())
                startActivity(intent)
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }

    }

}